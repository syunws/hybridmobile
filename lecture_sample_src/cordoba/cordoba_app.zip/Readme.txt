https://cordova.apache.org/docs/ko/latest/guide/cli/

cordova create device examples.hybridapp.device DeviceApp
cd device

기본 장치 정보 (장치 API):
$ cordova plugin add cordova-plugin-device

네트워크 연결 및 배터리 이벤트:
$ cordova plugin add cordova-plugin-network-information
$ cordova plugin add cordova-plugin-battery-status

속도계, 나침반, 및 지리적 위치:
$ cordova plugin add cordova-plugin-device-motion
$ cordova plugin add cordova-plugin-device-orientation
$ cordova plugin add cordova-plugin-geolocation

cordova platform add android

-------------------------------------

cordova create camera examples.hybridapp.camera CameraApp
cd camera

카메라, 미디어 재생 및 캡처:

$ cordova plugin add cordova-plugin-camera
$ cordova plugin add cordova-plugin-media

cordova platform add android

-------------------------------------

cordova create book examples.hybridapp.book BookApp
cd book

장치 또는 네트워크 (파일 API) 액세스 파일:

$ cordova plugin add cordova-plugin-file

cordova platform add android

